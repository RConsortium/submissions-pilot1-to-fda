# pilot3 0.0.1

* First release of 5 functions for use in Submission.
* Removed redundant files and cleaned up function names.

